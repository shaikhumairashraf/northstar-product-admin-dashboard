"use client";
import { useEffect, useState } from "react";
import LoginScreen from "@/components/LoginScreen";
import Dashboard from "@/components/Dashboard";
import type { AuthUser } from "@/lib/types";
function App() { 
  const [user, setUser] = useState<AuthUser | null>(null); 
  const [ready, setReady] = useState(false); 
  useEffect(() => { 
    const timer = setTimeout(() => {
    try { 
      const raw = localStorage.getItem("admin_user"); 
      if (raw) setUser(JSON.parse(raw)); 
    } catch { 
      localStorage.removeItem("admin_user"); 
    } 
    setReady(true);
    }, 0);
    return () => clearTimeout(timer);
  }, []); 
  function logout() { 
    localStorage.removeItem("admin_token"); 
    localStorage.removeItem("admin_user"); 
    setUser(null); 
  } 
  if (!ready) return <div className="full-loader">Loading workspace...</div>; 
  return user ? <Dashboard user={user} onLogout={logout} /> : <LoginScreen onLogin={setUser} />; 
}

export default function Home() { return <App />; }
