export type Review = { rating: number; comment: string; date: string; reviewerName: string; reviewerEmail: string };

export type Product = {
  id: number;
  title: string;
  description: string;
  category: string;
  price: number;
  discountPercentage: number;
  rating: number;
  stock: number;
  tags: string[];
  brand?: string;
  sku?: string;
  weight?: number;
  dimensions?: { width: number; height: number; depth: number };
  warrantyInformation?: string;
  shippingInformation?: string;
  availabilityStatus?: string;
  reviews?: Review[];
  returnPolicy?: string;
  minimumOrderQuantity?: number;
  thumbnail: string;
  images: string[];
};

export type ProductsResponse = { products: Product[]; total: number; skip: number; limit: number };
export type AuthUser = { id: number; username: string; email: string; firstName: string; lastName: string; image?: string; accessToken: string };
export type ProductDraft = Pick<Product, "title" | "description" | "category" | "price" | "stock" | "brand">;
