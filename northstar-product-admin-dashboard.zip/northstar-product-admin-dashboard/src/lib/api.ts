import axios from "axios";
import type { AuthUser, Product, ProductDraft, ProductsResponse } from "./types";

export const api = axios.create({ baseURL: "https://dummyjson.com", timeout: 12000 });

api.interceptors.request.use((config) => {
  if (typeof window !== "undefined") {
    const token = localStorage.getItem("admin_token");
    if (token) config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use((response) => response, (error) => {
  const message = error.response?.data?.message || error.message || "Something went wrong";
  return Promise.reject(new Error(message));
});

export async function login(username: string, password: string) {
  const { data } = await api.post<AuthUser>("/auth/login", { username, password, expiresInMins: 60 });
  return data;
}

export async function getProducts(params: { limit: number; skip: number; search?: string; category?: string; sort?: string; order?: "asc" | "desc" }, signal?: AbortSignal) {
  const path = params.search ? "/products/search" : params.category ? `/products/category/${encodeURIComponent(params.category)}` : "/products";
  const { data } = await api.get<ProductsResponse>(path, { params: { q: params.search || undefined, limit: params.limit, skip: params.skip, sortBy: params.sort || undefined, order: params.order || undefined }, signal });
  return data;
}

export async function getCategories() {
  const { data } = await api.get<Array<string | { slug: string; name: string }>>("/products/categories");
  return data.map((category) => typeof category === "string" ? category : category.slug);
}
export async function getProduct(id: string, signal?: AbortSignal) { const { data } = await api.get<Product>(`/products/${id}`, { signal }); return data; }
export async function createProduct(draft: ProductDraft) { const { data } = await api.post<Product>("/products/add", draft); return data; }
export async function updateProduct(id: number, draft: ProductDraft) { const { data } = await api.put<Product>(`/products/${id}`, draft); return data; }
export async function deleteProduct(id: number) { const { data } = await api.delete<Product>(`/products/${id}`); return data; }
