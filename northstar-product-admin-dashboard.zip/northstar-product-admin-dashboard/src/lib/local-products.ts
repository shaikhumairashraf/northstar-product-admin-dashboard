import type { Product, ProductDraft } from "./types";

const KEY = "admin_product_changes";
type Changes = { created: Product[]; updated: Record<number, Product>; deleted: number[] };
const empty = (): Changes => ({ created: [], updated: {}, deleted: [] });
export function getChanges(): Changes { if (typeof window === "undefined") return empty(); try { return { ...empty(), ...JSON.parse(localStorage.getItem(KEY) || "{}")} } catch { return empty(); } }
function save(changes: Changes) { localStorage.setItem(KEY, JSON.stringify(changes)); }
export function applyChanges(products: Product[]) { const c = getChanges(); return [...c.created, ...products.map((p) => c.updated[p.id] || p)].filter((p) => !c.deleted.includes(p.id)); }
export function saveCreated(product: Product) { const c = getChanges(); c.created = [product, ...c.created]; save(c); }
export function saveUpdated(product: Product) { const c = getChanges(); c.updated[product.id] = product; save(c); }
export function saveDeleted(id: number) { const c = getChanges(); c.deleted.push(id); save(c); }
export function draftToProduct(draft: ProductDraft, id: number): Product { return { ...draft, id, rating: 0, discountPercentage: 0, tags: [], thumbnail: "https://cdn.dummyjson.com/product-images/1/thumbnail.jpg", images: ["https://cdn.dummyjson.com/product-images/1/1.jpg"] }; }
