import Link from "next/link";
import { usePathname } from "next/navigation";
import { LayoutGrid, Package, TrendingUp } from "./Icons";

export default function Sidebar({ onAdd }: { onAdd: () => void }) {
  const pathname = usePathname();
  const isHome = pathname === "/";

  return (
    <aside className="sidebar">
      <div className="brand-mark">
        <span className="brand-dot" />
        <span>Northstar</span>
      </div>
      <nav>
        <span className="nav-label">Workspace</span>
        <Link href="/?page=1" className={`nav-item${isHome ? " active" : ""}`}>
          <LayoutGrid size={18} /> Overview
        </Link>
        <Link href="/?page=1" className={`nav-item${isHome ? " active" : ""}`}>
          <Package size={18} /> Products
        </Link>
        <span className="nav-item muted-nav" title="Analytics is coming soon">
          <TrendingUp size={18} /> Analytics <span className="soon">Soon</span>
        </span>
      </nav>
      <div className="side-bottom">
        <div className="tip">
          <span>Quick action</span>
          <strong>Add a product</strong>
          <button className="add-mini" onClick={onAdd}>+</button>
        </div>
        <small>Northstar Admin · v1.0</small>
      </div>
    </aside>
  );
}
