"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import {
  ChevronLeft,
  ChevronRight,
  DollarSign,
  List,
  LogOut,
  Package,
  Pencil,
  Plus,
  Search,
  Star,
  Trash2,
  TrendingUp,
  SlidersHorizontal,
  LayoutGrid,
} from "./Icons";
import Sidebar from "./Sidebar";
import ProductForm from "./ProductForm";
import { EmptyState, ErrorState, LoadingState } from "./StatusState";
import { deleteProduct, getCategories, getProducts } from "@/lib/api";
import { applyChanges, saveDeleted } from "@/lib/local-products";
import type { AuthUser, Product } from "@/lib/types";

const pageSizes = [10, 20, 50];
function validPage(value: string | null) {
  const number = Number(value);
  return Number.isInteger(number) && number > 0 ? number : 1;
}
function validSize(value: string | null) {
  const number = Number(value);
  return pageSizes.includes(number) ? number : 10;
}

export default function Dashboard({
  user,
  onLogout,
}: {
  user: AuthUser;
  onLogout: () => void;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const params = useSearchParams();
  const page = validPage(params.get("page"));
  const size = validSize(params.get("size"));
  const search = params.get("search") || "";
  const category = params.get("category") || "";
  const sort = params.get("sort") || "";
  const [query, setQuery] = useState(search);
  const [products, setProducts] = useState<Product[]>([]);
  const [total, setTotal] = useState(0);
  const [categories, setCategories] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [editing, setEditing] = useState<Product>();
  const [showForm, setShowForm] = useState(false);
  const [view, setView] = useState<"table" | "grid">("table");
  const setParams = useCallback(
    (values: Record<string, string>) => {
      const next = new URLSearchParams(params.toString());
      Object.entries(values).forEach(([key, value]) =>
        value ? next.set(key, value) : next.delete(key),
      );
      router.push(`${pathname}?${next.toString()}`);
    },
    [params, pathname, router],
  );
  useEffect(() => {
    const timer = setTimeout(
      () => setParams({ search: query, page: "1" }),
      420,
    );
    return () => clearTimeout(timer);
  }, [query]);
  useEffect(() => {
    getCategories()
      .then(setCategories)
      .catch(() => setCategories([]));
  }, []);
  const load = useCallback(() => {
    const controller = new AbortController();
    setLoading(true);
    setError("");
    getProducts(
      {
        limit: size,
        skip: (page - 1) * size,
        search,
        category,
        sort: sort ? sort.split(":")[0] : undefined,
        order: sort ? (sort.split(":")[1] as "asc" | "desc") : undefined,
      },
      controller.signal,
    )
      .then((data) => {
        setProducts(applyChanges(data.products));
        setTotal(data.total);
      })
      .catch((e) => {
        if (e.name !== "CanceledError" && e.name !== "AbortError")
          setError(e.message);
      })
      .finally(() => setLoading(false));
    return () => controller.abort();
  }, [page, size, search, category, sort]);
  useEffect(() => {
    const timer = setTimeout(() => load(), 0);
    return () => clearTimeout(timer);
  }, [load]);
  const visibleProducts = useMemo(
    () => products.filter((p) => !category || p.category === category),
    [products, category],
  );
  const totalPages = Math.max(1, Math.ceil(total / size));
  const first = total === 0 ? 0 : (page - 1) * size + 1;
  const last = Math.min(page * size, total);
  const pageNumbers = Array.from(
    { length: Math.min(totalPages, 5) },
    (_, index) =>
      totalPages <= 5
        ? index + 1
        : Math.max(1, Math.min(page - 2 + index, totalPages - 4)),
  ).filter((number, index, numbers) => numbers.indexOf(number) === index);
  function remove(product: Product) {
    if (
      !window.confirm(
        `Delete “${product.title}”? This change will be kept in this browser session.`,
      )
    )
      return;
    deleteProduct(product.id)
      .then(() => {
        saveDeleted(product.id);
        setProducts((current) => current.filter((p) => p.id !== product.id));
        setTotal((value) => Math.max(0, value - 1));
      })
      .catch((e) => setError(e.message));
  }
  function saved(product: Product) {
    setShowForm(false);
    setEditing(undefined);
    setProducts((current) =>
      editing
        ? current.map((p) => (p.id === product.id ? product : p))
        : [product, ...current],
    );
    setTotal((value) => (editing ? value : value + 1));
  }
  return (
    <div className="app-shell">
      <Sidebar onAdd={() => setShowForm(true)} />
      <main className="main-content">
        <header className="topbar">
          <div>
            <p className="eyebrow">Thursday, September 24, 2026</p>
            <h1>Product overview</h1>
          </div>
          <div className="top-actions">
            <div className="avatar">
              {user.firstName?.[0] || "E"}
              {user.lastName?.[0] || "M"}
            </div>
            <div className="user-name">
              <strong>
                {user.firstName} {user.lastName}
              </strong>
              <span>Administrator</span>
            </div>
            <button
              className="icon-button"
              onClick={onLogout}
              title="Log out"
              aria-label="Log out"
            >
              <LogOut size={18} />
            </button>
          </div>
        </header>
        <section className="metrics">
          <div className="metric-card accent">
            <span className="metric-icon">
              <Package size={17} />
            </span>
            <span className="metric-label">Total products</span>
            <strong>{total || "—"}</strong>
            <small>
              <TrendingUp size={13} /> Live catalog count
            </small>
          </div>
          <div className="metric-card">
            <span className="metric-icon green">
              <DollarSign size={17} />
            </span>
            <span className="metric-label">Avg. price</span>
            <strong>
              $
              {visibleProducts.length
                ? (
                    visibleProducts.reduce((sum, p) => sum + p.price, 0) /
                    visibleProducts.length
                  ).toFixed(2)
                : "0.00"}
            </strong>
            <small>Across current view</small>
          </div>
          <div className="metric-card">
            <span className="metric-icon gold">
              <Star size={17} />
            </span>
            <span className="metric-label">Avg. rating</span>
            <strong>
              {visibleProducts.length
                ? (
                    visibleProducts.reduce((sum, p) => sum + p.rating, 0) /
                    visibleProducts.length
                  ).toFixed(1)
                : "0.0"}
            </strong>
            <small>Customer sentiment</small>
          </div>
          <div className="metric-card">
            <span className="metric-icon blue">
              <Package size={17} />
            </span>
            <span className="metric-label">Low stock</span>
            <strong>
              {visibleProducts.filter((p) => p.stock < 20).length}
            </strong>
            <small>Needs attention</small>
          </div>
        </section>
        <section className="catalog-section">
          <div className="section-heading">
            <div>
              <p className="eyebrow">Inventory</p>
              <h2>
                All products <span>{total}</span>
              </h2>
            </div>
            <button
              className="primary-button"
              onClick={() => setShowForm(true)}
            >
              <Plus size={17} /> Add product
            </button>
          </div>
          <div className="toolbar">
            <div className="search-box">
              <Search size={18} />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search products..."
              />
              <kbd>⌘ K</kbd>
            </div>
            <div className="filter-wrap">
              <SlidersHorizontal size={16} />
              <select
                value={category}
                onChange={(e) =>
                  setParams({ category: e.target.value, page: "1" })
                }
              >
                <option value="">All categories</option>
                {categories.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
            <select
              className="sort-select"
              value={sort}
              onChange={(e) => setParams({ sort: e.target.value, page: "1" })}
            >
              <option value="">Sort by: default</option>
              <option value="price:asc">Price: low to high</option>
              <option value="price:desc">Price: high to low</option>
              <option value="rating:desc">Rating: highest</option>
              <option value="title:asc">Title: A-Z</option>
            </select>
            <div className="view-toggle">
              <button
                className={view === "table" ? "selected" : ""}
                onClick={() => setView("table")}
                aria-label="Table view"
              >
                <List size={17} />
              </button>
              <button
                className={view === "grid" ? "selected" : ""}
                onClick={() => setView("grid")}
                aria-label="Grid view"
              >
                <LayoutGrid size={17} />
              </button>
            </div>
          </div>
          {search && (
            <div className="active-filter">
              Searching for <b>“{search}”</b>
              <button
                onClick={() => {
                  setQuery("");
                  setParams({ search: "", page: "1" });
                }}
              >
                Clear
              </button>
            </div>
          )}
          {loading ? (
            <LoadingState />
          ) : error ? (
            <ErrorState message={error} onRetry={load} />
          ) : !visibleProducts.length ? (
            <EmptyState />
          ) : view === "grid" ? (
            <div className="product-grid">
              {visibleProducts.map((p) => (
                <ProductCard
                  key={p.id}
                  product={p}
                  onEdit={() => {
                    setEditing(p);
                    setShowForm(true);
                  }}
                  onDelete={() => remove(p)}
                />
              ))}
            </div>
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Product</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Rating</th>
                    <th>Stock</th>
                    <th />
                  </tr>
                </thead>
                <tbody>
                  {visibleProducts.map((p) => (
                    <tr key={p.id}>
                      <td>
                        <Link
                          href={`/products/${p.id}`}
                          className="product-cell"
                        >
                          <img src={p.thumbnail} alt="" />
                          <span>
                            <strong>{p.title}</strong>
                            <small>{p.brand || "No brand"}</small>
                          </span>
                        </Link>
                      </td>
                      <td>
                        <span className="category-pill">{p.category}</span>
                      </td>
                      <td>
                        <strong>${p.price.toFixed(2)}</strong>
                      </td>
                      <td>
                        <span className="rating">
                          <Star size={14} fill="currentColor" />{" "}
                          {p.rating.toFixed(1)}
                        </span>
                      </td>
                      <td>
                        <span className={p.stock < 20 ? "stock low" : "stock"}>
                          {p.stock} units
                        </span>
                      </td>
                      <td>
                        <div className="row-actions">
                          <button
                            onClick={() => {
                              setEditing(p);
                              setShowForm(true);
                            }}
                            aria-label="Edit product"
                          >
                            <Pencil size={16} />
                          </button>
                          <button
                            onClick={() => remove(p)}
                            aria-label="Delete product"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          <footer className="pagination">
            <span>
              Showing{" "}
              <b>
                {first}–{last}
              </b>{" "}
              of <b>{total}</b>
            </span>
            <div className="page-controls">
              <button
                disabled={page <= 1}
                onClick={() => setParams({ page: String(page - 1) })}
              >
                <ChevronLeft size={16} /> Previous
              </button>
              {pageNumbers.map((number) => (
                <button
                  key={number}
                  className={number === page ? "current" : ""}
                  onClick={() => setParams({ page: String(number) })}
                >
                  {number}
                </button>
              ))}
              <button
                disabled={page >= totalPages}
                onClick={() => setParams({ page: String(page + 1) })}
              >
                Next <ChevronRight size={16} />
              </button>
            </div>
            <select
              value={size}
              onChange={(e) => setParams({ size: e.target.value, page: "1" })}
            >
              {pageSizes.map((s) => (
                <option key={s} value={s}>
                  {s} / page
                </option>
              ))}
            </select>
          </footer>
        </section>
      </main>
      {showForm && (
        <ProductForm
          product={editing}
          onClose={() => {
            setShowForm(false);
            setEditing(undefined);
          }}
          onSaved={saved}
        />
      )}
    </div>
  );
}
function ProductCard({
  product,
  onEdit,
  onDelete,
}: {
  product: Product;
  onEdit: () => void;
  onDelete: () => void;
}) {
  return (
    <article className="product-card">
      <img src={product.thumbnail} alt="" />
      <div className="product-card-body">
        <span className="category-pill">{product.category}</span>
        <Link href={`/products/${product.id}`}>
          <h3>{product.title}</h3>
        </Link>
        <div className="card-meta">
          <strong>${product.price.toFixed(2)}</strong>
          <span className="rating">
            <Star size={13} fill="currentColor" /> {product.rating}
          </span>
        </div>
        <div className="card-actions">
          <span className={product.stock < 20 ? "stock low" : "stock"}>
            {product.stock} in stock
          </span>
          <span>
            <button onClick={onEdit} aria-label="Edit">
              <Pencil size={15} />
            </button>
            <button onClick={onDelete} aria-label="Delete">
              <Trash2 size={15} />
            </button>
          </span>
        </div>
      </div>
    </article>
  );
}
