import { CircleAlert, LoaderCircle, RefreshCw } from "./Icons";
export function LoadingState() { return <div className="status-state"><LoaderCircle className="spin" size={28} /><span>Loading catalog...</span></div> }
export function EmptyState() { return <div className="status-state"><span className="empty-icon">∅</span><strong>No products found</strong><span>Try changing your search or filters.</span></div> }
export function ErrorState({ message, onRetry }: { message: string; onRetry: () => void }) { return <div className="status-state"><CircleAlert size={28} /><strong>We hit a snag</strong><span>{message}</span><button className="secondary-button" onClick={onRetry}><RefreshCw size={16} /> Retry</button></div> }
