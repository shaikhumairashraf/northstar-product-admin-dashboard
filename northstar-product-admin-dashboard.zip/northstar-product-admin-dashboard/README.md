 # Northstar Product Admin

A polished product operations dashboard built for the frontend assignment with Next.js, React, Tailwind CSS, Axios, and the DummyJSON API.

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000 and sign in with `emilys` / `emilyspass`.

## Finished

- Auth login with token injection, logout, loading and invalid-credential errors.
- Responsive product table on desktop and card grid on mobile / grid toggle.
- URL-backed search, category, sort, page and page-size state.
- Debounced search with AbortController cancellation so stale responses cannot win.
- Pagination with validated URL values and 10 / 20 / 50 page sizes.
- Product detail route with reviews and a friendly 404 state.
- Add, edit and delete forms with validation, duplicate-submit protection and delete confirmation.
- Loading, empty, retryable error, and no-result states.

## Decisions and tradeoffs

DummyJSON does not support combining `search` and category filtering. The UI keeps the category control visible while searching, but search is sent to `/products/search` and category is applied to the returned page locally. This makes the behavior predictable and avoids pretending the API supports a query it cannot represent.

DummyJSON mutation endpoints return a simulated response and do not persist changes. Successful add/edit/delete actions are therefore written to a small localStorage overlay and merged into subsequent list/detail responses for this browser session. The API call still runs, making the integration realistic while keeping the requested changes visible.

## AI note

AI helped with the initial project scaffolding, component decomposition, and implementation review. The request flow, URL state rules, cancellation behavior, local mutation overlay, and validation were checked against the assignment requirements.

## Getting Started

First, run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can start editing the page by modifying `app/page.tsx`. The page auto-updates as you edit the file.

## Learn More

To learn more about Next.js, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.

You can check out [the Next.js GitHub repository](https://github.com/vercel/next.js) - your feedback and contributions are welcome!

## Deploy on Vercel

The easiest way to deploy your Next.js app is to use the [Vercel Platform](https://vercel.com/new?utm_medium=default-template&filter=next.js&utm_source=create-next-app&utm_campaign=create-next-app-readme) from the creators of Next.js.

Check out our [Next.js deployment documentation](https://nextjs.org/docs/app/building-your-application/deploying) for more details.
